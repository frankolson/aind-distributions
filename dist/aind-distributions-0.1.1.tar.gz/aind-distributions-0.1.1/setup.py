from setuptools import setup

setup(name='aind-distributions',
      version='0.1.1',
      description='Gaussian and Binomial distributions',
      packages=['aind_distributions'],
      author='Will Olson',
      author_email='will.olson11@gmail.com',
      zip_safe=False)
